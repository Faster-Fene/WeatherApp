package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.WeatherService;

@RestController
public class WeatherRestController {

	@Autowired
	private WeatherService weatherService;

	@RequestMapping("/getcurrentweather")
	public String getCurrentWeather(@RequestParam(value = "zipCode") String zipCode) {
		return weatherService.getCurrentWeather(zipCode);
	}
	
	@RequestMapping("/getforcastweather")
	public String getForcastWeather(@RequestParam(value = "zipCode") String zipCode) {
		return weatherService.getHourlyForcast(zipCode);
	}

}
