package com.example.demo.service;

public interface WeatherService {

	String getHourlyForcast(String zipCode);
	String getCurrentWeather(String zipCode);

}
