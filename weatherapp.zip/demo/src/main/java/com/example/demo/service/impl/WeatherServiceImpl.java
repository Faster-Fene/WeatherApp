package com.example.demo.service.impl;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.service.WeatherService;

@Service
public class WeatherServiceImpl implements WeatherService {

	
	@Override
	@Cacheable("zipCodeWeather")
	public String getCurrentWeather(String zipCode) {
		RestTemplate restTemplate = new RestTemplate();
		String fullyQualifiedURL = String.format("http://api.openweathermap.org/data/2.5/weather?zip=%s,us&mode=html&appid=7110d2cacc756d16462663599f03485d", zipCode);
		String currentWeather = restTemplate.getForObject(fullyQualifiedURL, String.class);
		return currentWeather;
	}
	
	@Override
	@Cacheable("zipCodeForcast")
	public String getHourlyForcast(String zipCode) {
		RestTemplate restTemplate = new RestTemplate();
		String fullyQualifiedURL = String.format("http://api.openweathermap.org/data/2.5/forecast?zip=%s,us&appid=7110d2cacc756d16462663599f03485d", zipCode);
		String hourlyForcast = restTemplate.getForObject(fullyQualifiedURL, String.class);
		return hourlyForcast;
	}

}
