package com.example.demo.controller;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.controller.WeatherRestController;
import com.example.demo.service.WeatherService;

@RunWith(SpringRunner.class)
@WebMvcTest(WeatherRestController.class)
public class WeatherRestControllerTest {

	@MockBean
	private WeatherService weatherService;

	@Autowired
	private MockMvc mvc;

	@Test
	public void getCurrentWeather() throws Exception {
		given(this.weatherService.getCurrentWeather("61704")).willReturn("weather data");
		this.mvc.perform(get("/getcurrentweather?zipCode=61704"))
				.andExpect(status().isOk());
		verify(this.weatherService).getCurrentWeather("61704");
	}

	@Test
	public void getForecastWeather() throws Exception {
		given(this.weatherService.getHourlyForcast("6104")).willReturn("weather data");
		this.mvc.perform(get("/getforcastweather?zipCode=61704"))
				.andExpect(status().isOk());
		verify(this.weatherService).getHourlyForcast("61704");
	}


}
