package com.example.demo.service;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.service.WeatherService;

@RunWith(SpringRunner.class)
@RestClientTest(WeatherService.class)
public class WeatherServiceTest {


	@Mock
	private WeatherService weatherService;

	@Test
	public void testGetCurrentWeather() {
		Mockito.when(weatherService.getCurrentWeather("61704")).thenReturn("weather data");
		String actualWeatherData = weatherService.getCurrentWeather("61704");
		assertEquals("weather data", actualWeatherData);
	}	
	
	@Test
	public void testGetHourlyForcast() {
		Mockito.when(weatherService.getHourlyForcast("61704")).thenReturn("weather data");
		String actualWeatherData = weatherService.getHourlyForcast("61704");
		assertEquals("weather data", actualWeatherData);
	}
}
